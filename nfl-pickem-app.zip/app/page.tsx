import NFLPickemApp from "../nfl-pickem-app"

export default function Page() {
  return <NFLPickemApp />
}
